package cat.itacademy.s05.t01.n01.enums;

public enum PlayerStatus {
    PLAYING,
    STANDING,
    BUST,
    BLACKJACK
}
