package cat.itacademy.s05.t01.n01.controller;

import cat.itacademy.s05.t01.n01.model.PlayerRanking;
import cat.itacademy.s05.t01.n01.model.dto.playerDto.RankingDto;
import cat.itacademy.s05.t01.n01.model.dto.playerDto.UpdateNameDto;
import cat.itacademy.s05.t01.n01.service.impl.PlayerServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/player")
public class PlayerController {
    @Autowired
    private PlayerServiceImpl playerServiceImpl;

    @GetMapping("/ranking")
    public Flux<ResponseEntity<RankingDto>> getRanking(){
        return playerServiceImpl.getRanking().map(ResponseEntity::ok);
    }

    @PutMapping("/{playerId}")
    public Mono<ResponseEntity<PlayerRanking>> updatePlayerName
            (@PathVariable int playerId, @RequestBody @Valid UpdateNameDto request){
        return playerServiceImpl.updatePlayerName(playerId, request).map(ResponseEntity::ok);
    }
}
