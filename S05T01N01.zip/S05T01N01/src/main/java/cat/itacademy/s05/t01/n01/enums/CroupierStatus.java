package cat.itacademy.s05.t01.n01.enums;

public enum CroupierStatus {
    WAITING_TURN,
    PLAYING_TURN,
    FINISHED_TURN
}
