package cat.itacademy.s05.t01.n01.controller;

import cat.itacademy.s05.t01.n01.model.Game;
import cat.itacademy.s05.t01.n01.model.dto.gameDto.GameDto;
import cat.itacademy.s05.t01.n01.model.dto.gameDto.GameResponse;
import cat.itacademy.s05.t01.n01.model.dto.gameDto.PlayRequest;
import cat.itacademy.s05.t01.n01.model.dto.gameDto.NewGameDto;
import cat.itacademy.s05.t01.n01.model.dto.playerDto.PlayerDto;
import cat.itacademy.s05.t01.n01.service.impl.GameServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/game")
public class GameController {

    @Autowired
    private GameServiceImpl gameServiceImpl;

    @PostMapping("/new")
    public Mono<ResponseEntity<NewGameDto>> createGame(@RequestBody @Valid List<PlayerDto> players){
        return gameServiceImpl.createGame(players).map(game -> {
            NewGameDto gameDto = new NewGameDto(game);

            URI location = URI.create("/game/" + game.getId());
            return ResponseEntity.created(location).body(gameDto);
        }).onErrorResume(e -> Mono.just(ResponseEntity.badRequest().build()));
    }

    @GetMapping("/{id}")
    public Mono<ResponseEntity<Game>> getGameDetails(@PathVariable String id){
        return gameServiceImpl.getGameDetails(id).map(ResponseEntity::ok);
    }

    @PostMapping("/{id}/play")
    public Mono<ResponseEntity<GameResponse>> makeAMove(@PathVariable String id, @RequestBody(required = false) PlayRequest playRequest) {
        return gameServiceImpl.play(id, playRequest)
                .map(ResponseEntity::ok);
    }

    @DeleteMapping("/{id}/delete")
    public Mono<ResponseEntity<Game>> deleteGame(@PathVariable String id){
        return gameServiceImpl.deleteGame(id).then(Mono.just(ResponseEntity.noContent().build()));
    }
}
